import time
import ctypes

from lib.morai_udp_parser import udp_parser

IP = '127.0.0.1' 
PORT = 909

def main():
    EgoVehicelStatus = udp_parser(IP, PORT)
    while True :
        status = EgoVehicelStatus.get_data()
        print_ego_vehicle_status(status)        
        time.sleep(0.1)

def print_ego_vehicle_status(status):
    for field_name, _ in status._fields_:
        value = getattr(status, field_name)
        if isinstance(value, bytes):
            value = value.decode('utf-8')
        elif isinstance(value, ctypes.Array):
            value = list(value)
        print(f"{field_name}: {value}")        



if __name__ == '__main__':
    main()