#!/usr/bin/env python
# -*- coding: utf-8 -*-

import socket
import threading
import ctypes

from lib.define.EgoVehicleStatus import EgoVehicleStatus

class udp_parser :
    def __init__(self, ip, port):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.bind((ip,port))

        self.data_size = 65535
        self.parsed_data = EgoVehicleStatus()        
        threading.Thread(target=self.recv_udp_data, daemon=True).start()
        

    def recv_udp_data(self):
        while True :
            raw_data, _ = self.socket.recvfrom(self.data_size)
            self.data_parsing(raw_data)

    def data_parsing(self,raw_data) :
        ctypes.memmove(ctypes.addressof(self.parsed_data), raw_data, ctypes.sizeof(self.parsed_data))

    def get_data(self) :
        return self.parsed_data

    def __del__(self):
        self.socket.close()        
        print('del')